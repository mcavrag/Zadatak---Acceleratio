package zadatak1;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileFilter;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

/**
 * 
 * Class MainPanel is used as a container for all the required components.
 * 
 * @author Matija �avrag
 *
 */

public class MainPanel extends JPanel {

	/**
	 * Most important components which will be used in another class and their
	 * Getters and Setters.
	 */

	private JTextArea output = new JTextArea();

	private JPanel favorites = new JPanel();

	private JComboBox<String> favoriteFiles = new JComboBox<String>();

	public JTextArea getOutput() {
		return output;
	}

	public JPanel getFavorites() {
		return favorites;
	}

	public JComboBox<String> getFavoriteFiles() {
		return favoriteFiles;
	}

	public void setOutput(JTextArea output) {
		this.output = output;
	}

	public void setFavorites(JPanel favorites) {
		this.favorites = favorites;
	}

	public void setFavoriteFiles(JComboBox<String> favoriteFiles) {
		this.favoriteFiles = favoriteFiles;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of the class which is used to define and initialize all the
	 * required components and to manage certain actions (e.g. click on the
	 * button) and the response of the actions.
	 */

	public MainPanel() {

		setLayout(new BorderLayout());

		setBorder(new EmptyBorder(5, 5, 5, 5));

		/**
		 * Defining the JPanel which will be used as a storage for certain
		 * components (JLabel, input text as JTextField, output text as
		 * JTextArea and JButton to perform some action)
		 */

		JPanel grid = new JPanel();

		grid.setLayout(new GridLayout(3, 1));

		JLabel console = new JLabel("Unos putanje direktorija:");

		grid.add(console);

		JTextField inputText = new JTextField();

		grid.add(inputText);

		JButton okButton = new JButton("Po�alji");

		grid.add(okButton);

		add(grid, BorderLayout.NORTH);

		JScrollPane scroll = new JScrollPane(output);

		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		output.setEditable(false);

		///////////////////////////////////////////////////////////////////////

		/**
		 * 
		 * Setting up a Panel which will be used as a storage and management for
		 * the selected favorite files.
		 * 
		 */

		favorites.setLayout(new GridLayout(7, 1));

		favorites.setBorder(new TitledBorder("Favoriti"));

		JButton addToFavorites = new JButton("Dodaj u favorite");

		JButton removeFromFavorites = new JButton("Ukloni odabrane datoteke iz favorita");

		/**
		 * 
		 * Main ActionListener which sets the text of the output JTextArea.
		 * 
		 */

		okButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				output.setText("");
				;
				favoriteFiles.removeAllItems();

				int i;

				String query = inputText.getText();

				File folder = new File(query);

				if (!folder.exists()) {
					output.setText("Unijeli ste nepostoje�i put! Poku�ajte ponovo...");
					return;
				}

				File[] fileList = folder.listFiles(new FileFilter() {
					@Override
					public boolean accept(File pathname) {
						return pathname.isFile();
					}
				});

				String[] fragments = query.split("\\\\");

				for (i = 0; i < fragments.length; i++) {
					output.append(fragments[i] + "\n");
					for (int j = 0; j < (i + 1) * 2; j++) {
						output.append(" ");
					}
				}

				for (int j = 0; j < fileList.length; j++) {
					output.append(fileList[j].getName() + "\n");
					for (int k = 0; k < i * 2; k++) {
						output.append(" ");
					}
				}

				for (int j = 0; j < fileList.length; j++) {
					favoriteFiles.addItem(fileList[j].getName());
				}

			}

		});

		/**
		 * 
		 * An ActionListener used to perform an action of adding the selected
		 * file to the favorites list.
		 * 
		 */

		addToFavorites.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				favorites.revalidate();

				if (favoriteFiles.getSelectedItem() == null) {
					return;
				}
				String selected = favoriteFiles.getSelectedItem().toString();

				Component[] comp = favorites.getComponents();

				for (Component c : comp) {
					if (c.getAccessibleContext().getAccessibleName().equals(selected)) {
						JOptionPane.showMessageDialog(c,
								"Poku�ali ste dodati datoteku sa istim imenom koja ve� postoji u favoritima.\nPreimenujte datoteku ili izbri�ite postoje�u iz favorita i poku�ajte ponovno.",
								"Ups!", JOptionPane.WARNING_MESSAGE);
						return;
					}
				}

				favorites.add(new JCheckBox(selected));

			}

		});
		
		/**
		 * 
		 * An ActionListener used to perform an action of removing the selected
		 * files from the favorites list.
		 * 
		 */

		removeFromFavorites.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				Component[] comp = favorites.getComponents();

				for (Component c : comp) {
					if (c instanceof JCheckBox) {
						if (((JCheckBox) c).isSelected()) {
							favorites.remove(c);
						}
					}
				}

				favorites.revalidate();
				favorites.repaint();

			}
		});

		add(scroll, BorderLayout.CENTER);
		
		/**
		 * 
		 * JPanel's used for styling the applications components
		 * 
		 */

		JPanel gridSouth = new JPanel();

		gridSouth.setLayout(new BorderLayout());

		///////////////////////////////////////////////////////////////

		JPanel gridSubSouth = new JPanel();

		gridSubSouth.setLayout(new GridLayout(2, 1));

		gridSubSouth.add(favoriteFiles);

		gridSubSouth.add(addToFavorites);

		gridSouth.add(gridSubSouth, BorderLayout.NORTH);

		///////////////////////////////////////////////////////////////

		JPanel favoritesGrid = new JPanel();

		favoritesGrid.setLayout(new BorderLayout());

		favoritesGrid.add(favorites, BorderLayout.NORTH);

		favoritesGrid.add(removeFromFavorites, BorderLayout.SOUTH);

		gridSouth.add(favoritesGrid, BorderLayout.SOUTH);

		///////////////////////////////////////////////////////////////

		add(gridSouth, BorderLayout.SOUTH);

	}

}
