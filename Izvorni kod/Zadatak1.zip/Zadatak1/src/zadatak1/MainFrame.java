package zadatak1;

import java.awt.Component;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * Class MainFrame is used to create the frame of the application. It stores and
 * show the main panel and controls the actions on closing and opening of the
 * application.
 * 
 * @author Matija �avrag
 *
 */
public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * A MainPanel object which is used to add all the components and to store
	 * information from the components which is used as some sort of memory.
	 * 
	 */

	private static MainPanel mainPanel;

	/**
	 * The main constructor which initializes the mainPanel object and displays
	 * it.
	 */

	public MainFrame() {

		mainPanel = new MainPanel();

		setContentPane(mainPanel);

	}

	/**
	 * The main function used to initialize the frame and set the parameters. It
	 * also controls what happens on closing and opening the application.
	 * 
	 * @param args
	 *            is not used
	 */

	public static void main(String[] args) {
		MainFrame mainFrame = new MainFrame();

		mainFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		mainFrame.setSize(300, 500);

		mainFrame.setVisible(true);

		mainFrame.setTitle("Zadatak 1");

		mainFrame.setResizable(false);

		mainFrame.addWindowListener(new WindowListener() {

			/**
			 * 
			 * Defines what happens before the application is closed. In this
			 * case the data from components of mainPanel object is stored in
			 * the .txt file used as a memory.
			 * 
			 */

			@Override
			public void windowClosing(WindowEvent e) {

				String[] options = new String[2];
				options[0] = new String("Da");
				options[1] = new String("Ne");
				if (JOptionPane.showOptionDialog(mainFrame, "Jeste li sigurni da �elite iza�i?", "Potvrdite izlazak.",
						0, JOptionPane.INFORMATION_MESSAGE, null, options, null) != 0) {
					return;
				} else {

					BufferedWriter out;
					try {
						out = new BufferedWriter(new OutputStreamWriter(
								new BufferedOutputStream(new FileOutputStream("Database.txt")), "UTF-8"));
						if (!mainPanel.getOutput().getText().startsWith("Unijeli")) {

							out.write(mainPanel.getOutput().getText());

						}

						out.write("|");

						StringBuilder output = new StringBuilder();

						for (int i = 0; i < mainPanel.getFavoriteFiles().getItemCount(); i++) {
							out.write(mainPanel.getFavoriteFiles().getItemAt(i) + " ");
						}

						out.write("|");

						Component[] files = mainPanel.getFavorites().getComponents();

						for (int i = 0; i < files.length; i++) {
							output.append(((JCheckBox) files[i]).getActionCommand() + " ");
						}

						out.write(output.toString());

						out.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}

					System.exit(-1);
				}
			}

			@Override
			public void windowActivated(WindowEvent e) {
			}

			@Override
			public void windowClosed(WindowEvent e) {
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
			}

			@Override
			public void windowIconified(WindowEvent e) {
			}

			BufferedReader in;

			/**
			 * 
			 * Defines what happens when the application has started. In this
			 * case the mainPanel object's components are set.
			 * 
			 */

			@Override
			public void windowOpened(WindowEvent e) {

				try {
					in = new BufferedReader(new InputStreamReader(
							new BufferedInputStream(new FileInputStream("Database.txt")), "UTF-8"));
					StringBuilder data = new StringBuilder();
					String line;

					while ((line = in.readLine()) != null) {
						data.append(line);
					}

					if (data.toString().trim().equals("")) {
						return;
					}

					String[] fragments = data.toString().split("\\|");

					int i = 0, j = 0, k = 0;

					if (!(fragments.length < 1)) {

						String[] areaText = fragments[0].split("  +");

						File testFile;

						String testString = "";

						for (i = 0; i < areaText.length; i++) {
							mainPanel.getOutput().append(areaText[i] + "\n");
							testString += areaText[i] + "\\\\";
							testFile = new File(testString);
							if (testFile.isDirectory()) {
								for (j = 0; j < (i + 1) * 2; j++) {
									mainPanel.getOutput().append(" ");
								}
							} else {
								for (k = 0; k < j; k++) {
									mainPanel.getOutput().append(" ");
								}
							}
						}

					} else {
						mainPanel.getOutput().setText("");
					}

					if (!(fragments.length < 2)) {
						String[] comboBoxes = fragments[1].trim().split(" ");

						for (i = 0; i < comboBoxes.length; i++) {
							mainPanel.getFavoriteFiles().addItem(comboBoxes[i]);
						}
					}

					if (fragments.length < 3) {
						in.close();
						return;
					}

					String[] checkBoxes = fragments[2].trim().split(" ");

					for (i = 0; i < checkBoxes.length; i++) {

						mainPanel.getFavorites().add(new JCheckBox(checkBoxes[i]));

					}

					in.close();

				} catch (UnsupportedEncodingException e1) {
					e1.printStackTrace();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
	}

}
